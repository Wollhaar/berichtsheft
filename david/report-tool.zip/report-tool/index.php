<?php
require_once 'model/config.php';

/*
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $request = filter_input(INPUT_POST, 'case', filter_id(513));
}
elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $request = filter_input(INPUT_GET, 'case', filter_id(513));
}*/

$request = $_REQUEST;
    //? isset($_POST['case']) : array('case' => '');
//var_dump($request);

switch ($request['case']) {
    case 'login':
        $temp = 'home';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $login = array( 'username' => $request['username'], 'password' => $request['password']);
            if (isset($login)) {
                $user = new DB_User();
                $check = $user->login($login['username'], $login['password']);
            }
            elseif (isset($login) && is_object($user)) {
                $check = $user->login($login['username'], $login['password']);
            }
            if(is_string($check)) {
                die($check);
            }
            if (is_object($user)) {
                $access = $user->checkLogin($check);
            }
        }
        break;

    case 'register':
        $temp = 'register';

        if (isset($request['username'])&& $request['password'] && $request['email']) {
            $regist = array('username' => $request['username'], 'password' => $request['password'], 'email' => $request['email'],
                'first_name' => $request['first_name'], 'last_name' => $request['last_name'], 'adress' => $request['adress'],
                'PLZ' => $request['PLZ'], 'place' => $request['place'], 'birthday' => $request['birthday']);
            if (is_object($user)) {
                $fb = $user->registUser($regist);
            }
            else {
                $user = new DB_User();
                $fb = $user->registUser($regist);
            }
        }
        break;

    default:
        $temp = 'home';
}

require_once 'view/html/layout.html';
